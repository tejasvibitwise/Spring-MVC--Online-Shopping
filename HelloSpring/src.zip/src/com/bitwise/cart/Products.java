package com.bitwise.cart;

public class Products {
	
	String productName;
	int price,quantity;
	
	
	public Products()
	{
		
		
		
	}

	
	
}
