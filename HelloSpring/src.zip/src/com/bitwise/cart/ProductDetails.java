package com.bitwise.cart;

public class ProductDetails {
	
	

	private String name;
	private int price,quantity;

	public ProductDetails(String name, int price, int quantity) {
		super();
		this.name = name;
		this.price = price;
		this.quantity = quantity;
	}

	

}
