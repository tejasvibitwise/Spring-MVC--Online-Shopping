package com.bitwise.spring1;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;


import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.bitwise.cart.ProductBean;
import com.bitwise.cart.ProductDetails;
import com.bitwise.spring1.LoginBean;
import com.sun.org.apache.xml.internal.serialize.Printer;


@Controller
//@RequestMapping("/helloworld")
public class LoginController {
@Autowired
LoginBean loginbean;
@Autowired
LoginValidator loginvalidator;


//	@RequestMapping(method = RequestMethod.GET)
//	public String helloPrint(Model model)
//	{
//		model.addAttribute("message","hello bitwiser");
//		return("hello");
//	}
	
	@RequestMapping(value="/login",method = RequestMethod.GET)
    public String init(Model model) {
		//model.addAttribute("message","Please enter following details");
		model.addAttribute("LoginBean", new LoginBean());
	    return "login";
    }
 
	
		
	@RequestMapping(method = RequestMethod.POST)
	   public String submit(Model model, @ModelAttribute("LoginBean") LoginBean loginBean,BindingResult result) {
	
	loginvalidator.validate(loginBean, result);

	if(result.hasErrors()) return "login";
	else
		{
		model.addAttribute("message","Online shopping");
		model.addAttribute("ProductBean",new ProductBean());
		return "success";
		}
	 }
	 
	 @ModelAttribute("itemlist")
	 public List<ProductDetails> populateWebFrameworkList() {

	 	//Data referencing for web framework checkboxes
//	 	List<String> productlist = new ArrayList<String>();
//	 	productlist.add("Product 1");
//	 	productlist.add("Product 2");
//	 	productlist.add("Product 3");
//	 	productlist.add("Product 4");
//	 	productlist.add("Product 5");
	 	
	 	
		List<ProductDetails> itemlist=new ArrayList<ProductDetails>();
		
		itemlist.add(new ProductDetails("product 1",10,20));
		itemlist.add(new ProductDetails("product 2",30,40));
		
	 	
	 	return itemlist;
	 }



	@Override
	public String toString() {
		return "LoginController [loginbean=" + loginbean + ", loginvalidator="
				+ loginvalidator + "]";
	}



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((loginbean == null) ? 0 : loginbean.hashCode());
		result = prime * result
				+ ((loginvalidator == null) ? 0 : loginvalidator.hashCode());
		return result;
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LoginController other = (LoginController) obj;
		if (loginbean == null) {
			if (other.loginbean != null)
				return false;
		} else if (!loginbean.equals(other.loginbean))
			return false;
		if (loginvalidator == null) {
			if (other.loginvalidator != null)
				return false;
		} else if (!loginvalidator.equals(other.loginvalidator))
			return false;
		return true;
	}
	 
//	@RequestMapping(value="/products",method = RequestMethod.POST)
//	public String selectedProductsubmit(Model model, @ModelAttribute("ProductBean") ProductBean productBean,BindingResult result) {
//		
//		 model.addAttribute("list",productBean.getProducts());
//		return "products";
//		 
//	
//	}
	 
	 
}
